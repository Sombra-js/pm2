import requests

url = "http://localhost:5002/api/send"  # ou o IP da VPS: http://IP:5002/api/send

html_message = """
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px; }
    .container { background-color: #ffffff; padding: 20px; border-radius: 8px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); }
    h1 { color: #1a73e8; }
    p { font-size: 16px; color: #333333; }
    .footer { font-size: 12px; color: #999999; margin-top: 20px; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Olá José Leonardo!</h1>
    <p>Esta é uma mensagem de teste enviada via nosso servidor MTevolution.</p>
    <p>HTML completo está funcionando corretamente! 🚀</p>
    <div class="footer">MTevolution - Suporte</div>
  </div>
</body>
</html>
"""

payload = {
    "prefix": "TESTE",
    "to": "joseleonardoramos2003@gmail.com",
    "subject": "Mensagem HTML de Teste",
    "message": html_message,
    "is_html": True
}

response = requests.post(url, json=payload)
print(response.json())
