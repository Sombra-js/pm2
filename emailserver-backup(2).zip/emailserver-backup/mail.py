from flask import Flask, request, jsonify
import subprocess
import base64
import re
import datetime
import os
import tempfile

app = Flask(__name__)
app.secret_key = "chave_super_secreta"

FROM_EMAIL = "suporte@neuratechmz.tech"

# -------------------------
# Validar email
# -------------------------
def email_valido(email: str) -> bool:
    padrao = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(padrao, email) is not None

# -------------------------
# LOG INTERNO
# -------------------------
def salvar_log(msg):
    with open("log_envio.txt", "a") as f:
        f.write(f"[{datetime.datetime.now()}] {msg}\n")

# -------------------------
# Função: montar e enviar email (HTML ou texto, com ou sem anexo)
# -------------------------
def enviar_email(prefix, to_email, subject, message, attachment_path=None, is_html=False):
    try:
        boundary_main = "BOUNDARY_MAIN_MTEVOLUTION"
        boundary_alt = "BOUNDARY_HTML_MTEVOLUTION"

        # Header base
        headers = f"""From: {FROM_EMAIL}
To: {to_email}
Subject: [{prefix}] {subject}
MIME-Version: 1.0
"""

        # Corpo do email
        if attachment_path:
            headers += f"Content-Type: multipart/mixed; boundary={boundary_main}\n\n"
            email_body = f"--{boundary_main}\n"
            if is_html:
                # multipart/alternative dentro do mixed
                email_body += f"Content-Type: multipart/alternative; boundary={boundary_alt}\n\n"
                # fallback texto
                email_body += f"--{boundary_alt}\nContent-Type: text/plain; charset=UTF-8\n\n"
                email_body += "Você precisa de um cliente que suporte HTML para ver esta mensagem.\n\n"
                # HTML
                email_body += f"--{boundary_alt}\nContent-Type: text/html; charset=UTF-8\nContent-Transfer-Encoding: 7bit\n\n"
                email_body += message + "\n"
                email_body += f"--{boundary_alt}--\n"
            else:
                email_body += f"Content-Type: text/plain; charset=UTF-8\n\n{message}\n\n"

            # Adiciona anexo
            with open(attachment_path, "rb") as f:
                encoded = base64.b64encode(f.read()).decode()
            filename = os.path.basename(attachment_path)
            email_body += f"--{boundary_main}\n"
            email_body += f"Content-Type: application/octet-stream; name=\"{filename}\"\n"
            email_body += f"Content-Disposition: attachment; filename=\"{filename}\"\n"
            email_body += "Content-Transfer-Encoding: base64\n\n"
            email_body += encoded + "\n"
            email_body += f"--{boundary_main}--"
        else:
            if is_html:
                headers += f"Content-Type: multipart/alternative; boundary={boundary_alt}\n\n"
                email_body = f"--{boundary_alt}\nContent-Type: text/plain; charset=UTF-8\n\n"
                email_body += "Você precisa de um cliente que suporte HTML para ver esta mensagem.\n\n"
                email_body += f"--{boundary_alt}\nContent-Type: text/html; charset=UTF-8\nContent-Transfer-Encoding: 7bit\n\n"
                email_body += message + "\n"
                email_body += f"--{boundary_alt}--"
            else:
                headers += "Content-Type: text/plain; charset=UTF-8\n\n"
                email_body = message

        # Monta mensagem final
        mensagem_email = headers + email_body

        # Envio via sendmail
        processo = subprocess.Popen(
            ["sendmail", "-t", "-oi"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        _, stderr = processo.communicate(mensagem_email)

        if processo.returncode != 0:
            salvar_log(f"ERRO SENDMAIL: {stderr}")
            return False, stderr

        return True, "Enviado"

    except Exception as e:
        salvar_log(f"EXCEPTION: {str(e)}")
        return False, str(e)

# --------------------------------------
# ROTA 1 — ENVIO via FORM-DATA
# --------------------------------------
@app.route("/send", methods=["POST"])
def send_form():
    prefix = request.form.get("prefix", "")
    to_email = request.form.get("to")
    subject = request.form.get("subject", "")
    message = request.form.get("message", "")
    is_html = request.form.get("is_html", "false").lower() == "true"

    if not email_valido(to_email):
        return {"error": "Email inválido"}, 400

    attachment = request.files.get("attachment_upload")
    attachment_path = None
    if attachment:
        temp = tempfile.NamedTemporaryFile(delete=False)
        attachment.save(temp.name)
        attachment_path = temp.name

    ok, resp = enviar_email(prefix, to_email, subject, message, attachment_path, is_html)

    if attachment_path:
        os.unlink(attachment_path)

    return {"status": "success" if ok else "error", "message": resp}

# --------------------------------------
# ROTA 2 — ENVIO via JSON POST
# --------------------------------------
@app.route("/api/send", methods=["POST"])
def send_json():
    data = request.get_json()
    prefix = data.get("prefix", "")
    to_email = data.get("to")
    subject = data.get("subject", "")
    message = data.get("message", "")
    is_html = data.get("is_html", False)

    if not email_valido(to_email):
        return jsonify({"error": "Email inválido"}), 400

    ok, resp = enviar_email(prefix, to_email, subject, message, is_html=is_html)

    return jsonify({"status": "success" if ok else "error", "message": resp})

# --------------------------------------
# Home
# --------------------------------------
@app.route("/")
def home():
    return "API de envio de emails MTevolution - OK"

# --------------------------------------
# Executar servidor
# --------------------------------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002, debug=True)
